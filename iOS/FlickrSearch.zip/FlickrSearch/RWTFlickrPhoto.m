//
//  Created by Colin Eberhardt on 26/04/2014.
//  Copyright (c) 2014 Colin Eberhardt. All rights reserved.
//

#import "RWTFlickrPhoto.h"

@implementation RWTFlickrPhoto

- (NSString *)description {
    return self.title;
}

@end
